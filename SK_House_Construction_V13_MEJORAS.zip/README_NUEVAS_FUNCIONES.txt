V13 - Nuevas funciones
1. Imágenes por artículo/concepto:
   - Agregar una o varias imágenes.
   - Añadir texto editable a cada imagen (ej. Trabajo por realizar, m², metros lineales, descripción).
   - Eliminar imágenes.
   - Las imágenes y sus textos aparecen en la vista previa del documento.
2. Nueva pestaña Lista de Herramientas:
   - Crear listas editables.
   - Agregar/eliminar herramientas.
   - Cantidad y unidad.
   - Nombre y fecha.
   - Observaciones.
   - Vista previa con logotipo SK House Construction.
   - Guardado local en la V13; cuando se conecte la nube, se puede sincronizar con Supabase.
