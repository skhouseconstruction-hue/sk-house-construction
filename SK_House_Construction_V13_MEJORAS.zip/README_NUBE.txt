SK HOUSE CONSTRUCTION - BASE DE DATOS EN LINEA

Esta versión añade sincronización entre dispositivos mediante Supabase.

1) Crea un proyecto en Supabase.
2) En Supabase > SQL Editor ejecuta SUPABASE_SETUP.sql.
3) En Project Settings > API copia:
   - Project URL
   - Publishable key (o la anon key si tu proyecto todavía la muestra así)
4) Abre la app > Configuración > Base de datos en línea.
5) Pega URL y clave, pulsa Guardar conexión.
6) Crea una cuenta con correo/contraseña o inicia sesión.
7) En cada celular/computadora repite solo la configuración de URL/clave y entra con LA MISMA cuenta.

La app guarda en la nube: configuración, clientes, productos/servicios, cotizaciones y notas de venta.
La sesión se conserva en el navegador. La tabla usa Row Level Security para que cada cuenta solo pueda leer y modificar su propio estado.

IMPORTANTE: NO uses una service_role/secret key en la aplicación. Usa únicamente la Publishable/anon key.
