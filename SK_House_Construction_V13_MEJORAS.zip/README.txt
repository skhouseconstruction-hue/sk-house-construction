SK HOUSE CONSTRUCTION - APP
============================
Aplicación web independiente, sin servidor ni base de datos externa.

Incluye:
- Cotizaciones y notas de venta
- Clientes y productos
- Historial
- IVA editable
- Datos bancarios
- Respaldo/restauración JSON
- Vista previa
- PDF
- Compartir PDF mediante el menú de compartir del teléfono cuando el navegador lo permite
- Logotipo oficial incluido como logo.jpg

Para Netlify:
1. Sube el contenido de esta carpeta (o el ZIP) mediante Netlify Drop.
2. No necesitas enlazar Git.
3. Abre la URL publicada.
